<?php

    session_start();
    require_once 'init.php';
    
    // abre a conexão
    $PDO = db_connect();
	$senha = isset($_POST['txtSenha']) ? $_POST['txtSenha'] : null;
	$sql = "SELECT senha FROM Usuario WHERE senha= :senha ";
    $stmt = $PDO->prepare($sql);
	$stmt->bindParam(':senha', $senha);			
	$stmt->execute();
           
  if($stmt->rowCount() > 0){
		 $_SESSION["ver"] = true;
         header ("Location:indexMain.php");
     }else{
         unset($_SESSION["ver"]);
         header ("Location:index.php");
     }
    
?>
