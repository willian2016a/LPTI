<?php
    require_once 'init.php';
    //abre a conexão
    $PDO = db_connect();
    //SQL para selecionar os registros
    $sql = "SELECT senha FROM Senha";
    // seleciona os registros
    $stmt = $PDO->prepare($sql);
    $stmt->execute();
?>   
<!DOCTYPE HTML>
<html>
	<head>
		<title>Imperium</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<script type = "text/javascript" src = "assets/js/jquery.min.js"></script>
	</head>
	<body class="landing">

		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
				 <!--->
					<header id="header" class="alt">
						<h1><a href="index.html">Imperium</a></h1>
					</header>
                  <!---->
				<!-- Banner -->
					<section id="banner">
						<div class="inner">
							<h2>Imperium</h2>
							<p>Gerenciador pessoal de registros acadêmicos</p>
							<form action="LoginVerifica.php" method="POST">
								<h5>Senha</h5>
								<input type="password" id="senha" name="txtSenha"><br>
								<input type="submit" value="Entrar">
								
							</form>
							
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/utilScreen.js"></script>
			<script src="assets/js/mainScreen.js"></script>

	</body>
</html>
