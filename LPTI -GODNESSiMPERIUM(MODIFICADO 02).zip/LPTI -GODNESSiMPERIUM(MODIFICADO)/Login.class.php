<?php
    class Login{
        private $idAdmin;
        private $senha;
      
    
        public function __construct($idAdmin, $senha){
            $this->setIdAdmin($idAdmin);
            $this->setSenha($senha);
        }
        
        public function getIdAdmin(){
            return $this->idAdmin;
        }
        
        public function setIdAdmin($idAdmin){
            $this->idAdmin = $idAdmin;
        }
        
        public function getSenha(){
            return $this->senha;
        }
        
        public function setSenha($senha){
            $this->senha = $senha;
        }
        
    }
?>
