<?php
 	class Turma{
		private $nomeTurma;
        private $qtdAula;
		
		public function __construct($nomeTurma, $qtdAula){
                $this->setNomeTurma($nomeTurma);
                $this->setQtdAula($qtdAula);
		}
		public function getNomeTurma(){
			return $this->nomeTurma;
		}
		public function setNomeTurma($nomeTurma){
			return $this->nomeTurma = $nomeTurma;
		}
        public function getQtdAula(){
			return $this->qtdAula;
		}
        public function setQtdAula($qtdAula){
			return $this->qtdAula = $qtdAula;
		}
    }
?>
