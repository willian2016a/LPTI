<?php
    require_once 'init.php';
    // abre a conexão
    $PDO = db_connect();
    $id = $_GET["id"];
    // SQL para selecionar os registros
    $sql = "SELECT idAtividade,nomeAtividade,valorAtividade,bimestreAtividade,tipoAtividade,idTurmaAtividade FROM Atividade WHERE idAtividade = :idAtividade ORDER BY nomeAtividade ASC";
    // seleciona os registros
    $stmt = $PDO->prepare($sql);
    //$stmt->execute(array(':idTurmaAluno' => $aux2));
   // $stmt->execute(array(':idTurma' => $aux));
    $stmt->execute(array(':idAtividade' => $id));
    $Atividade = $stmt->fetch(PDO::FETCH_ASSOC);
   // $aux = $Aluno['idTurmaAluno'];
    
	
	include_once 'Atividade.class.php';
   // $dadosOK = true;

       $nomeAtividade = isset($_POST['txtNomeAtividade']) ? $_POST['txtNomeAtividade'] : null;
       $valorAtividade = isset($_POST['txtValorAtividade']) ? $_POST['txtValorAtividade'] : null;
       $bimestreAtividade = isset($_POST['txtBimestreAtividade']) ? $_POST['txtBimestreAtividade'] : null;
       $tipoAtividade = isset($_POST['txtTipoAtividade']) ? $_POST['txtTipoAtividade'] : null;
       $idTurmaAtividade = NULL;
       
       $Atividade = new Atividade($nomeAtividade ,$valorAtividade , $bimestreAtividade,$tipoAtividade);

        $PDO = db_connect();
        
        $sql ="UPDATE Atividade SET nomeAtividade = :nomeAtividade, valorAtividade = :valorAtividade, tipoAtividade = :tipoAtividade, bimestreAtividade = :bimestreAtividade WHERE idAtividade = $id";
        $stmt = $PDO ->prepare($sql);
        $stmt ->bindParam(':nomeAtividade', $Atividade->getNomeAtividade());
        $stmt ->bindParam(':valorAtividade', $Atividade->getValorAtividade());
        $stmt ->bindParam(':bimestreAtividade', $Atividade->getBimestreAtividade());
        $stmt ->bindParam(':tipoAtividade', $Atividade->getTipoAtividade());
       
        

        if($stmt->execute()){
            header("Location: atividadeRegistro.php?id=$id");
        }else{
          echo"Erro ao  alterar";
        print_r($stmt ->errorInfo());
        }

       // echo $id;
   // endwhile;

    //header('Location: turmaRegistro.php');

?>
