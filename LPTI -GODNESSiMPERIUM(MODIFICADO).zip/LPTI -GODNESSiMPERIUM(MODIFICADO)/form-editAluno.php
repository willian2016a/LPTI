<?php

    session_start();
   if(!isset($_SESSION["ver"])){
	  header ("Location:index.php");
   } 
	require 'init.php';
	//pega o ID da URL
	$PDO = db_connect();
	$aux = $_GET["id"];
	$sql = "SELECT idAluno, nomeAluno, matricula, frequencia FROM Aluno WHERE idAluno = :idAluno ORDER BY nomeAluno ASC";
	$stmt = $PDO->prepare($sql);
	$stmt->execute(array(':idAluno' => $aux));
	$Aluno = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE HTML>
<html>
<head>
		<title>Imperium</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/mainScreen.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
<body>
<!-- Content -->
<div id="content">
    <div class="inner">
        <a href = "alunoRegistro.php?id=<?php echo $Aluno['idAluno'] ?>"><img src = "images/setaVoltar.png"></a><br>
        <!-- Post -->
        <form method ="post" name="formCadastro" action ="editAluno.php?id=<?php echo $Aluno['idAluno']?>" enctype="multipart/form-data">
        <h2>Alterando informações do Aluno</h2>
            <table width="100%">
                    <th width="18%">Nome do Aluno</th>
                    <td width="82%"><input type="text" name="txtNome" value="<?php echo $Aluno['nomeAluno']?>"></td>
                 </tr>
                <tr>
                    <th>Matrícula</th>
                    <td><input type="text" id="matricula" name="txtMatricula" value="<?php echo $Aluno['matricula']?>"></td>
                </tr>
                 <tr>
                    <th>Frequência</th>
                    <td><input type="number" id="frequencia" name="txtFrequencia" value="<?php echo $Aluno['frequencia']?>"></td>
                </tr>
                <tr>
                    <td><input type="hidden" id="IdAluno" name="txtIdAluno" value="<?php echo $Aluno['idTurmaAluno']?>"></td>
                </tr>
                <tr>
                    <td><input type="submit" name="btnEnviar" value="Salvar"></td>
                    <td><input type="reset" name="btnLimpar" value="Limpar"></td>
                </tr>
            </table>
        </form>
    </div>
</div>

		<!-- Sidebar -->
			<div id="sidebar">

				<!-- Logo -->
					<h1 id="logo"><a href="#">Imperium</a></h1>


				<!-- Nav v-->
					<nav id="nav">
						<ul>
							<li><a href="indexMain.html">Principal</a></li>
							<li class="current"><a href="turmaRegistro.php">Registro de Alunos</a></li>
							<li><a href="calendario.html">Agenda</a></li>
							<li><a href="atividadeLista.php">Atividades</a></li>
						</ul>
					</nav>
	
				<!-- Copyright -->
					<ul id="copyright">
						<li>&copy; CEFET-MG Unidade Varginha.</li><li>Design: Edgard Alexandre, Larissa Rodrigues, Pedro Barbosa, Willian Alves</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/utilScreen.js"></script>
			<script src="assets/js/mainScreen.js"></script>

	</body>
</html>
