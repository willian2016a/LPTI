<?php
    class Nota{
        private $idAtividade;
        private $idAluno;
        private $valorNota;
    
        public function __construct($idAtividade, $idAluno, $valorNota){
            $this->setIdAtividade($idAtividade);
            $this->setIdAluno($idAluno);
            $this->setValorNota($valorNota);
        }
        
        public function getIdAtividade(){
            return $this->idAtividade;
        }
        
        public function setIdAtividade($idAtividade){
            $this->idAtividade = $idAtividade;
        }
        
        public function getIdAluno(){
            return $this->idAluno;
        }
        
        public function setIdAluno($idAluno){
            $this->idAluno = $idAluno;
        }
        
        public function getValorNota(){
          return $this->valorNota;
        }
        
       	public function setValorNota($valorNota){
          $this->valorNota = $valorNota;
        }
    }
?>