<?php
   session_start();
   if(!isset($_SESSION["ver"])){
	  header ("Location:index.php");
   } 
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Imperium</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/mainScreen.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<link rel='stylesheet' href='fullcalendar/fullcalendar.css'/>
	</head> 
	<body>

		<!-- Content -->
			<div id="content">
				<div class="inner">

					<!-- Post -->
						<article class="box post post-excerpt">
							<header>
								<!--
									Note: Titles and subtitles will wrap automatically when necessary, so don't worry
									if they get too long. You can also remove the <p> entirely if you don't
									need a subtitle.
								-->
								<h2><a href="#">Bem Vindo ao Imperium</a></h2>
								<p>Seu Gerenciador Pessoal Acadêmico</p>
							</header>
							<p>
								<strong>Olá!</strong> Você esta olhando para o <strong>Imperium</strong>, um gerenciador de registros academicos pessoais com design minimalista
								para uso em escolas e faculdades/universidades. Ele oferece o registro e a visualização de notas, geração de relatórios e exibição de status escolar
								de alunos individualmente/coletivamente, além de oferecer um controle sobre as atividades extra-curriculares desejadas.
							</p>
							<p>
								Desenvolvido pelos alunos do 3º Informática(2014-2016) do CEFET-MG de Varginha-MG, o <strong>Imperium</strong> tem como finalidade ser um facilitador
								dos profissionais da educação no que se diz em respeito ao controle de seus alunos, além de ser uma agenda com ferramentas facilitadoras tanto para
								atividades pessoais quanto profissionais. Aproveite!
							</p>
		
						</article>
				</div>
			</div>

		<!-- Sidebar -->
			<div id="sidebar">

				<!-- Logo -->
					<h1 id="logo"><a href="#">Imperium</a></h1>


				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li class="current"><a href="indexMain.html">Principal</a></li>
							<li><a href="turmaRegistro.php">Registro de Alunos</a></li>
							<li><a href="calendario.html">Agenda</a></li>
							<li><a href="atividadeLista.php">Atividades</a></li>
						</ul>
					</nav>
			
				<!-- Copyright -->
					<ul id="copyright">
						<li>&copy; CEFET-MG Unidade Varginha.</li><li>Design: Edgard Alexandre, Larissa Rodrigues, Pedro Barbosa, Willian Alves</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/utilScreen.js"></script>
			<script src="assets/js/mainScreen.js"></script>
			<script src='fullcalendar/lib/jquery.min.js'></script>
			<script src='fullcalendar/lib/moment.min.js'></script>
			<script src='fullcalendar.js'></script>
	</body>
</html>
